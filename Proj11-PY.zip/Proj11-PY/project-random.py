# python Project-101

import random


usr_name=input("Enter your name:  ")




while True:
    user=input("Enter your choice: ")
    comp=random.choice(['rock','paper','scissors'])
    print(f"Computer chose: {comp} ")
    
    if comp==user:
        print("Tied!. Try again")
        continue

    elif user=='rock' and comp=='scissors':
        print(f" {usr_name} won the game...")
        break
    

    elif user=='scissors' and comp=='paper':
        print(f" {usr_name} won the game...")
        break
    

    elif user=='paper' and comp=='rock':
        print(f" {usr_name} won the game...")
        break
    # else:
    #     print("lost")
    

    elif comp=='rock' and user=='scissors':
        print(" Computer won the game...")
        break
    

    elif comp=='scissors' and user=='paper':
        print(" Computer won the game...")
        break
      

    elif comp=='paper' and user=='rock':
        print(" Computer won the game...")
        break
    
