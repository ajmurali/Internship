# Project API fetching

import requests
while True:
    name=input("Enter the Character Name: ")
    name=name.lower()
    link=f"https://pokeapi.co/api/v2/pokemon/{name}"

    req=requests.get(link)

    if req.status_code==200:
        character=req.json()
        char_dict=dict(character)

    # print(char_dict)

        print(f"Name:\t{char_dict['name']}")
        print("moves: ")

        for index,game in enumerate(char_dict['moves']):
            print(index+1,'\t',game['move']['name'])

    else:
        print("Character not found...\n Enter a valid character...!!!")        